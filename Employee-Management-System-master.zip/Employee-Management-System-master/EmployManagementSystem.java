import java.util.*;
import java.io.*;

class MainMenu {
    public void menu() {
        System.out.println("\t\t*******************************************");
        System.out.println("\t\t\t  EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("\t\t*******************************************");
        System.out.println("\t\t\t     CHAHAT AGRAWAL");
        System.out.println("\n\nPress 1 : To Add an Employee Details");
        System.out.println("Press 2 : To See an Employee Details");
        System.out.println("Press 3 : To Remove an Employee");
        System.out.println("Press 4 : To Update Employee Details");
        System.out.println("Press 5 : To Exit the EMS Portal");
    }
}

class Employee_Add {
    public void createFile() {
        Scanner sc = new Scanner(System.in);
        EmployDetail emp = new EmployDetail();
        emp.getInfo();
        try {
            File f1 = new File("file" + emp.employ_id + ".txt");
            if (f1.createNewFile()) {
                FileWriter myWriter = new FileWriter("file" + emp.employ_id + ".txt");
                myWriter.write("Employee ID: " + emp.employ_id + "\n" +
                               "Employee Name: " + emp.name + "\n" +
                               "Father's Name: " + emp.father_name + "\n" +
                               "Employee Contact: " + emp.employ_contact + "\n" +
                               "Email Information: " + emp.email + "\n" +
                               "Employee Position: " + emp.position + "\n" +
                               "Employee Salary: " + emp.employ_salary);
                myWriter.close();
                System.out.println("\nEmployee has been Added.");
                sc.nextLine();
            } else {
                System.out.println("\nEmployee already exists.");
                sc.nextLine();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

class EmployDetail {
    String name, father_name, email, position, employ_id, employ_salary, employ_contact;

    public void getInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Employee's Name: ");
        name = sc.nextLine();
        System.out.print("Enter Employee's Father Name: ");
        father_name = sc.nextLine();
        System.out.print("Enter Employee's ID: ");
        employ_id = sc.nextLine();
        System.out.print("Enter Employee's Email ID: ");
        email = sc.nextLine();
        System.out.print("Enter Employee's Position: ");
        position = sc.nextLine();
        System.out.print("Enter Employee Contact Info: ");
        employ_contact = sc.nextLine();
        System.out.print("Enter Employee's Salary: ");
        employ_salary = sc.nextLine();
    }
}

class Employee_Show {
    public void viewFile(String id) throws Exception {
        File file = new File("file" + id + ".txt");
        Scanner sc = new Scanner(file);
        while (sc.hasNextLine()) {
            System.out.println(sc.nextLine());
        }
    }
}

class Employee_Remove {
    public void removeFile(String id) {
        File file = new File("file" + id + ".txt");
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("\nEmployee has been removed successfully.");
            }
        } else {
            System.out.println("\nEmployee does not exist.");
        }
    }
}

class Employee_Update {
    public void updateFile(String id, String oldData, String newData) throws IOException {
        File file = new File("file" + id + ".txt");
        Scanner sc = new Scanner(file);
        String fileContent = "";
        while (sc.hasNextLine()) {
            fileContent += "\n" + sc.nextLine();
        }
        FileWriter writer = new FileWriter("file" + id + ".txt");
        fileContent = fileContent.replaceAll(oldData, newData);
        writer.write(fileContent);
        writer.close();
    }
}

class CodeExit {
    public void out() {
        System.out.println("\n*****************************************");
        System.out.println("Thank You For Using the EMS Portal.");
        System.out.println("*****************************************");
        System.exit(0);
    }
}

class EmployManagementSystem {
    public static void main(String[] args) {
        System.out.print("\033[H\033[2J");
        Scanner sc = new Scanner(System.in);
        Employee_Show epv = new Employee_Show();
        int choice = 0;
        MainMenu obj1 = new MainMenu();
        obj1.menu();

        while (choice != 5) {
            System.out.print("\nPlease Enter Choice: ");
            choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1:
                    new Employee_Add().createFile();
                    System.out.print("\033[H\033[2J");
                    obj1.menu();
                    break;
                case 2:
                    System.out.print("\nPlease Enter Employee's ID: ");
                    String id = sc.nextLine();
                    try {
                        epv.viewFile(id);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    System.out.print("\nPress Enter to Continue...");
                    sc.nextLine();
                    System.out.print("\033[H\033[2J");
                    obj1.menu();
                    break;
                case 3:
                    System.out.print("\nPlease Enter Employee's ID: ");
                    new Employee_Remove().removeFile(sc.nextLine());
                    System.out.print("\nPress Enter to Continue...");
                    sc.nextLine();
                    System.out.print("\033[H\033[2J");
                    obj1.menu();
                    break;
                case 4:
                    System.out.print("\nPlease Enter Employee's ID: ");
                    id = sc.nextLine();
                    try {
                        epv.viewFile(id);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    System.out.print("Enter Current Data: ");
                    String oldData = sc.nextLine();
                    System.out.print("Enter New Data: ");
                    String newData = sc.nextLine();
                    try {
                        new Employee_Update().updateFile(id, oldData, newData);
                    } catch (IOException e) {
                        System.out.println(e);
                    }
                    System.out.print("\nPress Enter to Continue...");
                    sc.nextLine();
                    System.out.print("\033[H\033[2J");
                    obj1.menu();
                    break;
                case 5:
                    new CodeExit().out();
                    break;
                default:
                    System.out.println("Invalid Choice. Try Again.");
            }
        }
    }
}

